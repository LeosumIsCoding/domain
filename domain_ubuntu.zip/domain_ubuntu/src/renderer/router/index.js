import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

import LoginWindow from '../components/LoginWindow.vue'

import MainWindow from "../components/MainWindow.vue"

import Home from "../components/MainWindow/Home.vue"

import Dyn from "../components/MainWindow/Dyn.vue"

import Friends from "../components/MainWindow/Friends.vue"

import Sets from "../components/MainWindow/Sets.vue"

import MyZone from "../components/MainWindow/MyZone.vue"

import SessionWidget from "../components/MainWindow/SessionWidget.vue"

export default new Router({
  routes: [
    {
      path: '/',
      name: 'landing-page',
      component: require('@/components/LandingPage').default
    },
    {
      path: '/LoginWindow',
      // redirect: '/'
      component:LoginWindow
    },
    {
      path:'/MainWindow',
      component:MainWindow,
      children:[{
        path:"/MainWindow/Home",
        component:Home
      },{
        path:"/MainWindow/Dyn",
        component:Dyn
      },{
        path:"/MainWindow/Friends",
        component:Friends,
        children:[{
          path:"/MainWindow/Friends/SessionWidget/:data",
          component:SessionWidget
        }]
      },{
        path:"/MainWindow/Sets",
        component:Sets
      },{
        path:"/MainWindow/MyZone",
        component:MyZone
      }]
    }
  ]
})

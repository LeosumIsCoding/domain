// 该文件用于创建vuex中最核心的store

// 引入Vue
import Vue from 'vue'
// 引入Vuex
import Vuex from 'vuex'


// console.log(Vue,"hahahahahahahha");
// 准备actions--用于响应组件中的动作
const action = {


};

//准备mutations -- 用与操作数据（state）
const mutations = {


    getUserById(id){
        // this.$http.get("http://localhost:4536/User/userExist",{
        //     params:{
        //         username:id
        //     }
        // }).then((res)=>{
        //     // console.log(res);
        //     if(res.data === 0){
        //         this.usernameExist = false;
        //     }else{
        //         this.usernameExist = true;
        //     }
        // }).catch((err)=>{
        //     console.log(err, "请求异常");
        //     // alert("haha");
        // })
        console.log(id,this);
    }
    
};



// 准备state--用于存储数据
const state = {
    LoginId:null,
    LoginPassword:null,

    RegId:0,
    RegPassword:0,

    isLogin:false,
    isLoginIdExist:false
};


const getters = {


}

Vue.use(Vuex)
export default new Vuex.Store({
    actions:action,
    mutations:mutations,
    state:state,
    getters
})
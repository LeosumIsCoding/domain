<template>
  <div id="login-win" ref="loginWin">

    <aside class="left">

    </aside>

    <aside class='right'>
        <RightWidget/>
    </aside>

    <header id="login-border">
        <div>
12123
        </div>
        <div id="ipc">
            <!-- <button>主</button> -->
            <!-- <button @click="openDevTool">d</button> -->
            <button @click="mixWindow"><img src="../assets/Login/min.png" alt="" width="10px"></button>
            <button @click="closeWindow"><img src="../assets/Login/close.png" alt="" width="10px"></button>
        </div>
    </header>
  </div>
</template>

<script>
// import LoginBorderbar from './LoginWindow/LoginBorderBar.vue'

import { ipcRenderer } from 'electron';
import RightWidget from './LoginWindow/RightWidget.vue'
export default {
    name:'LoginWindow',
    components:{RightWidget},

    mounted() {
        ipcRenderer.on('loginWinSizeChanged',(event,size)=>{
            this.$refs.loginWin.style.height = size.height +'px';
        });

        // console.log(this);
    },
    methods: {
        mixWindow(){
            ipcRenderer.send("minLoginWindow");
        },
        closeWindow(){
            ipcRenderer.send("closeLoginWindow");
        }
    },
}
</script>

<style scoped>
#login-win{
    height: 100%;
    width: 100%;
    /* background-color: antiquewhite; */
}

.left{
    position: fixed;
    left: 0px;
    width: 380px;
    height: 100%;
    /* background-color: rgb(255, 255, 255); */
    background-image: url('../assets/stardust--Login.png');
    background-size: cover ;
    background-position: center;
    border-radius: 15px 0px 0px 15px; 
}
.right{
    position: fixed;
    right: 0px;
    width: 250px;
    height: 100%;
    background-color: rgb(255, 255, 255);
    border-radius: 15px;
    box-shadow: -2px 0px 40px rgba(0, 0, 0, 0.256);
}

#login-border{
    position: fixed;
    top: 0px;
    width: 100%;
    height: 30px;
    /* background-color: aqua; */
    border-radius: 15px 15px 0px 0px;
    -webkit-app-region: drag;

    display: flex;
    justify-content: space-between;
    overflow:hidden;
}
#ipc{
    -webkit-app-region: no-drag;
    height: 100%;
    position: relative;
    right: 0px;
    border-radius: 15px 15px 0px 0px;
    /* background-color: aqua; */
}

#ipc >button{
    border: none;
    background-color: #fff;
    width: 50px;
    height: 100%;
    border-radius: 0px;
}

#ipc >button:hover{
    background-color: rgb(223, 223, 223);
}
</style>


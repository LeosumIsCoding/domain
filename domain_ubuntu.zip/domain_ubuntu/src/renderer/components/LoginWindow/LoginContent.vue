<template>
    <div class="login-right">

    <div id="login-headimg">
        <LoginHeadimg ref="headimg" :isReg='false' headimgSize="70px" />
    </div>

    <div id="login-inputs">
        <input v-model="username" type="text" maxlength="15" placeholder="请输入账号">
        <input v-model="password" type="password" maxlength="15" placeholder="请输入密码" >
    </div>

    <div id="buttons">
        <MyButton @click.native="login" buttomName="登录"  color="rgb(255, 255, 255)" backgroundColor="#35bcff"
            margin="0px 0px 0px 10px"
            width="180px"
        />

        <MyButton @click.native="go2Reg" buttomName="注册" color='rgb(255, 255, 255)' backgroundColor="#35bcff" width="180px" />
    </div>

  </div>
</template>

<script>
import { ipcRenderer } from 'electron'

import InputText from './InputText.vue'
import LoginHeadimg from './LoginHeadimg.vue'
import MyButton from './MyButton.vue'


export default {
    name:'LoginContent',
    components:{LoginHeadimg,InputText,MyButton},

    data() {
        return {
            username:null,
            password:null,
        }
    },

    watch:{
        username:function(n,o){
            this.$http.get("http://localhost:4536/User/userInfo",{
                params:{
                    username:n,
                }
            }).then(res=>{
                console.log(res);
                if(res.data === ""){
                    console.log("不存在");
                }else{
                    let headimg = res.data.headimg;
                    this.$refs.headimg.setHeadimg(headimg);
                }
            }, err=>{
                console.log(err);
            })
        }
    },

    mounted() {
        // console.log(this.$parent, "parent");
        
    },
    methods: {
        go2Reg(){
            this.$parent.isLogin = !this.$parent.isLogin;
            // console.log(this.$parent);
        },
        test(){
            console.log(this);
        },
        chan(){
            console.log(this);
        },
        login(){
            if(this.username === ""){
                alert("你还没输入账号");
            }else if(this.password === ""){
                alert("你还没输入密码");
            }else{
                this.$http.get("http://localhost:4536/User/userInfo",{
                    params:{
                        username:this.username
                    }
                }).then(res=>{
                    console.log(res.data);
                    let password = res.data.password;

                    if(password === this.password){
                        console.log("登录成功");

                        ipcRenderer.send("go2MainWindow", res)
                    }else{
                        alert("密码错误");
                    }
                }, err=>{
                    console.log(err);
                })
            }
        }
    },
    // store:LoginStore
}
</script>

<style scoped> 
.login-right{
    display: flex;
    justify-content: center;
    flex-direction: column;
    align-items: center;
    height: 100%;
    width: 100%;
    /* background-color: aqua; */
}

#login-headimg{
    margin-bottom: 30px;
    display: flex;
    flex-direction: column;
    justify-content: center;
}
#login-inputs{
    display: flex;
    flex-direction: column;
    margin-bottom: 20px;
}
#login-inputs > input{
    height: 30px;
    width: 180px;
    outline: none;
    border-radius: 20px;
    border: 1px solid rgba(0, 0, 0, 0.291);
    text-align: center;
    margin-bottom: 10px;
}

#buttons > button{
    width: 300px;
}
</style>
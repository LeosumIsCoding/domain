<template>
  <div >
    <input id="input" :type="inputType" :maxlength="maxLength"
    :style="{
        width,
        height,
        margin  
    }"
    >
  </div>
</template>

<script>

export default {
    name:'InputText',
    props:{
        inputType:{
            type:String,
            default:"text"
        },
        maxLength:{
            type:String,
            default:'15'
        },
        width:{
            type:String,
            default:'200px'
        },
        height:{
            type:String,
            default:'30px'
        },
        margin:{
            type:String,
            default:'10px 10px 10px 10px',
        },
        
    }
}
</script>

<style scoped>
#input{
    height: 30px;
    width: 200px;
    outline: none;
    border-radius: 20px;
    border: 1px solid rgba(0, 0, 0, 0.291);
    text-align: center;

}
</style>
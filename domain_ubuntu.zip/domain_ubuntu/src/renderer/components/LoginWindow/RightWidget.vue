<template>
  <div class="content">
    <LoginContent v-if="isLogin"/>
    <RegContent v-else/>
  </div>
</template>

<script>
import LoginContent from './LoginContent.vue'
import RegContent from './RegContent.vue'

// import { mapMutations, mapActions} from 'vuex'

import LoginStore from '../../store/LoginStore.js'
export default {
    name:"RightWidget",
    components:{
        LoginContent,RegContent
    },
    data() {
        return {
            isLogin:true
        }
    },

    store:LoginStore

}
</script>

<style scoped>
.content{
    height: 100%;
    width: 100%;


}
</style>
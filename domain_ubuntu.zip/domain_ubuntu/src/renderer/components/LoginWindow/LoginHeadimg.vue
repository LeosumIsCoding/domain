<template>
  <div class='login-headimg' :style="{
        backgroundImage:'url('+headimgStream+')',
        height:headimgSize,
        width:headimgSize,
        borderRadius:headimgSize,

    }">
    <input ref="headimg"   @change="headimgChanged" v-if="isReg" type="file" accept=".png" name="headimg" >
  </div>
</template>

<script>


import fs from 'fs';
import httpMixins from '../../mixins/httpMixins.js';
export default {
    name:'LoginHeadimg',
    data() {
        return {
            headimgStream:require('../../assets/defaultHeadimg.png'),
            headimgUrl:null,
        }
    },

    props:{
        isReg:{
            type:Boolean,
            default:false
        },
        headimgSize:{
            type:String,
            default:'50px'
        },
        id:{
            type:Number,
            default:0
        }

    },
    mixins:[httpMixins],

    mounted() {

    },
    
    methods: {
        headimgChanged(event){
            let dom = event.target
            let fileUrl = dom.files[0].path
             var reg=/\\/ig;
            fileUrl = fileUrl.replace(reg, '/');
            this.headimgUrl = fileUrl;
            
            fs.readFile(fileUrl,(err, data)=>{
                if(err){
                    console.log(err,"error");
                return;
                }else{
                    this.headimgStream = "data:image/png;base64,"+ data.toString('base64');
                }
            })
        },
        getHeadImgUrl(){
            return  this.$refs.headimg.files;
        },

        setHeadimg(name){
            this.headimgStream = `http://localhost:4536/photo?photoName=${name}`;
        }
    },
}
</script>

<style scoped>
.login-headimg{
    height: 50px;
    width: 50px;
    /* background-color: beige; */
    /* background-image: url('../../assets/head.jpg');    */
    background-size: 100% 100%;
    border-radius: 50px;
    box-shadow: 0px 1px 10px  rgba(0, 0, 0, 0.525);
}

.login-headimg input{
    opacity: 0;
    height: 100%;
    width: 100%;
}


</style>
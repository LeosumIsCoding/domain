<template>
  <div>
    <button id="my-button"  :style="{
        color,
        backgroundColor,
        width,
        height,
        margin
    }">
        {{buttomName}}
    </button>
  </div>
</template>

<script>
export default {
    name:'MyButton',

    props:{
        buttomName:{
            type:String,
            default:'按钮'
        },
        color:{
            type:String,
            default:'#000'
        },
        backgroundColor:{
            type:String,
            default:'#fff'
        },
        width:{
            type:String,
            default:'100px'
        },
        height:{
            type:String,
            default:'30px'
        },
        margin:{
            type:String,
            default:'10px 10px 10px 10px',
        },

    },

    methods:{

    }

}
</script>

<style scoped>
button{
        border: none;
    border-radius: 20px;
    outline:none
}


button:hover{
        opacity: 0.80;
        /* width: 40px; */
        
}
button:active{
        opacity:1;
         /* transform: translate(10px, 20px) rotate(45deg); */
        border: none;
}
</style>
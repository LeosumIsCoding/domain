<template>
    <div class="reg-right">

    <div id="reg-headimg">
        <LoginHeadimg ref="regHeadimg" :isReg='true' headimgSize="70px" />
    </div>

    <div id="reg-inputs">
        <p v-if="idExist" class="idExist">账号已被注册</p>
        <p v-else class="idNotExist"> 账号可用</p>
        <input v-model="username" type="text" maxlength="15" placeholder="请输入账号">
        <input v-model="regPassword" type="password" maxlength="15" placeholder="请输入密码" >
    </div>

    <div id="buttons">
        <MyButton @click.native='regAccount' buttomName="注册"  color="rgb(255, 255, 255)" backgroundColor="#35bcff"
            margin="0px 0px 0px 10px"
            width="180px"
        />

        <MyButton @click.native="go2Login" buttomName="登录" color='rgb(255, 255, 255)' backgroundColor="#35bcff" width="180px" />
    </div>

  </div>
</template>

<script>

import InputText from './InputText.vue'
import LoginHeadimg from './LoginHeadimg.vue'
import MyButton from './MyButton.vue'

import httpMixins from '../../mixins/httpMixins.js'
import fs from 'fs'

export default {
    name:'RegContent',
    components:{LoginHeadimg,InputText,MyButton},


    mounted() {
        // console.log(this.$parent, "parent");
        
    },
    data() {
        return {
            idExist:false,
            username:null,
            regPassword:null,
        }
    },

    watch:{
        username(n, o){
            this.$http.get("http://localhost:4536/User/userExist",{
                params:{
                    username:n
                }
            }).then((res)=>{
                if(res.data === 0){
                    this.idExist = false;
                }else if (res.data === 1){
                    this.idExist = true
                }else{
                    alert("网络异常");
                }
            }).catch(()=>{
                alert("网络异常")
            })      
        }
    },
    methods: {
        go2Login(){
            this.$parent.isLogin = !this.$parent.isLogin;

        },
        regAccount(){
            if(this.username === null){
                alert('你还未输入账号');
            }else if(this.regPassword === null){
                alert('你还未输入密码');
            }else if(this.idExist === true){
                alert('你所输入的账号已被注册');
            }else{
                let files = this.$refs.regHeadimg.getHeadImgUrl();
                if(files.length === 0){
                    console.log("空");
                    let data = {
                        username:this.username,
                        password:this.regPassword,
                        headimg:'default'
                    }
                    this.$http.post("http://localhost:4536/User/userInfo",data)
                    .then((res)=>{
                        console.log(res);
                    },(err)=>{
                        console.log(err);
                        alert("出现异常")
                        return;
                    })
                    alert("注册成功");
                    return;
                }else{
                    fileUrl = files[0].path;
                    let fileUrl = this.tranUrl(fileUrl);
                    fileUrl = this.tranUrl(fileUrl);
                    fs.readFile(fileUrl,(err, data)=>{
                        let dataStr = data.toString('base64');
                        let mydata = {
                            username:this.username,
                            password:this.regPassword,
                            headimg:dataStr
                        }
                        console.log(mydata);
                        this.$http.post('http://localhost:4536/User/userInfo', mydata)
                        .then((res)=>{
                            console.log(res);
                        },(err)=>{
                            console.log(err);
                            alert("出现异常");
                            return;
                        })
                    })
                    alert("注册成功")
                    
                }


            }
        },

    },
    mixins:[httpMixins],
    mounted(){

    }
}
</script>

<style scoped> 
.reg-right{
    display: flex;
    justify-content: center;
    flex-direction: column;
    align-items: center;
    height: 100%;
    width: 100%;
    /* background-color: aqua; */
}

#reg-headimg{
    margin-bottom: 30px;
    display: flex;
    flex-direction: column;
    justify-content: center;
}
#reg-inputs{
    display: flex;
    flex-direction: column;
    margin-bottom: 20px;
    /* background-color: antiquewhite; */
    position: relative;
}
.idExist{
    position: absolute;
    font-size: 8px;
    left: 130px;
    top: 30px;
    color: red;
}
.idNotExist{
        position: absolute;
    font-size: 8px;
    left: 130px;
    top: 30px;
    color: #66ccff;
}

#reg-inputs > input{
    height: 30px;
    width: 180px;
    outline: none;
    border-radius: 20px;
    border: 1px solid rgba(0, 0, 0, 0.291);
    text-align: center;
    margin-bottom: 10px;
}

#buttons > button{
    width: 300px;
}
</style>
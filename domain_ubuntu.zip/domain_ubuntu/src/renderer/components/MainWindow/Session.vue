<template>
    <router-link  :to="link"  class="session-a">
        <img :src="headimgSrc" alt="">
        <div>
            <div>{{friendData.username}}</div>
            <div>{{friendData.headimg}}</div>
        </div>
    </router-link>



</template>

<script>
export default {
    name:"Session",
    data() {
        return {
            friendData:{}
        }
    },

    computed:{
        link:function(){
            let data = JSON.stringify(this.friendData)
            // console.log(this.linkTo + "/"+ data , "dataaaaa");
            return this.linkTo + "/"+ data ;
        },
        headimgSrc:function(){
            // console.log(`http://localhost:4536/photo?photoName=${this.friendData.headimg}`);
            return `http://localhost:4536/photo?photoName=${this.friendData.headimg}`;
        }
    },

    props:{
        linkTo:{
            type:String,
            required:true
        },
        id:{
            required:true,
            type:Number,
        },
    },
    beforeMount() {
        // console.log(this.id);
        this.$http.get(`http://localhost:4536/friend/${this.id}`)
        .then(res=>{
            console.log(res, "res");
            this.friendData = res.data;
            this.friendData.msgList = [                
            {isMe:true, msg:"你好啊" + res.data.username, headimg:this.$store.state.myInfo.headimg},
            {isMe:false, msg:"我确实挺好", headimg:res.data.headimg},
            {isMe:true, msg:"你就是歌姬吧", headimg:this.$store.state.myInfo.headimg},
            {isMe:false, msg:"杀马特团长嗷", headimg:res.data.headimg}];

            // console.log(this.friendData);
        }, err=>{
            console.log(err);
        })

        // console.log(this.link);
    },


}
</script>

<style>
.session-a{
    display: flex;
    height: 50px;
    width: 100%;
    text-decoration: none;

    color: rgb(55, 55, 55);
    background-color: rgb(240, 240, 240);
}
.session-a:hover{
    background-color: rgb(214, 214, 214);
}
.session-a img{
    height: 40px;
    width: 40px;
    margin-left: 5px;
}
.session-a >div{
    display: flex;
    flex-direction: column;
    /* align-items: center; */
    justify-content:space-around;
    margin-left: 10px;
    height: 40px;
    width: 100px;
    /* background-color: aliceblue; */
    text-decoration: none;
    opacity: 0.75;
    /* background-color: aqua; */

}

.session-a >div>div:nth-child(1){
    font-weight: 900;
    text-overflow: ellipsis;
    font-size: 15px;
}
.session-a >div>div:nth-child(2){
    font-weight: 300;
    font-size: 12px;
    text-overflow: ellipsis;
    overflow: hidden;
}
</style>
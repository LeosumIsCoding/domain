<template>
    <aside id="main-right">
      <div id="main-header">
        <h2>Dyn</h2>
      </div>
      <div id="main-content"> 
        <h2>content</h2>
      </div>
    </aside>
</template>

<script>
export default {
    name:"Dyn"
}
</script>

<style scoped>
#main-right{
  flex: 1;
  /* background-color: beige; */
  display: flex;
  flex-direction: column;
}

#main-header{
  width: 100%;
  height: 80px;
  /* background-color: rgb(77, 115, 115); */
}

#main-content{
  flex: 1;
  /* background-color: brown; */
}
</style>
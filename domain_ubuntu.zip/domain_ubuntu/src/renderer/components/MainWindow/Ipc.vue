<template>
    <div id="ipc">
        <hr>
        <div @click="minMainWindow">
            <img src="../../assets/MainWindow/min.png" alt="">
        </div>
        <div @click="maxMainWindow"><img src="../../assets/MainWindow/max.png" alt=""></div>
        <div @click="closeMainWindow"><img src="../../assets/MainWindow/close.png" alt=""></div>
    </div>
</template>

<script>
import {ipcRenderer} from "electron"
export default {
    name:"Ipc",
    methods:{
        minMainWindow(){
            ipcRenderer.send("minMainWindow");
        },
        maxMainWindow(){
            ipcRenderer.send("maxMainWindow");
        },
        closeMainWindow(){
            ipcRenderer.send("closeMainWindow");
        }
    }
}
</script>

<style scoped>
hr{
    height: 20px;
    position: relative;
    top: 6px;
    opacity: 0.5;
}
#ipc{
    display: flex;
    margin-right: 30px;
}
#ipc > div{
    height: 30px;
    width: 30px;
    /* background-color: aqua; */
    margin-left: 10px;
    border-radius: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    opacity: 0.65;
}
#ipc > div:hover{
    background-color: rgb(205, 205, 205);
    opacity: 1;
}
#ipc img{

    height: 60%;

}
</style>
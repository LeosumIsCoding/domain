<template>
  <div id="header">
    <div>
        123
    </div>
    <div id="slog">
        345
    </div>
    <div>
        456
    </div>
  </div>
</template>

<script>
export default {
    name:"Header"
}
</script>

<style scoped>
#header{
    width: 100%;
    height: 100%;
    /* background-color: aquamarine; */
    display: flex;
    justify-content:space-between;
}
</style>
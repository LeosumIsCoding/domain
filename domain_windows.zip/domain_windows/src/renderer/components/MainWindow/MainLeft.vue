<template>
    <aside id="main-left">
        <div id="main-return">
            <div id="icon">
                <img src="../../assets/return.png" alt="" >
            </div>
        </div>

        <div id="main-select">
            <div>
                <router-link to="/MainWindow/Home">
                    <img src="../../assets/MainWindow/home.png" alt="">
                    <span>首页</span>
                </router-link>
            </div>
            <div>
                <router-link to="/MainWindow/Dyn">
                    <img src="../../assets/MainWindow/dyn.png" alt="">
                    <span>动态</span>
                </router-link>
            </div>
            <div>
                <router-link to="/MainWindow/Friends">
                    <img src="../../assets/MainWindow/friends.png" alt="">
                    <span>好友2</span>
                </router-link>
            </div>
        </div>

        <div id="main-select2">

            <div id="headimg">
                <Headimg  @click.native="go2MyZone" headimgSize="40px"/>
            </div>            
            <div>
                <router-link to="/MainWindow/Sets">
                    <img src="../../assets/MainWindow/sets.png" alt="">
                </router-link>
            </div>
        </div>
    </aside>
</template>

<script>
import Headimg from "./Headimg.vue"
export default {
    name:"MainLeft",
    components:{
        Headimg
    },
    methods:{
        go2MyZone(){
            this.$router.push("/MainWindow/MyZone")
        }
    }
}
</script>

<style>
#main-left{
  /* position: fixed; */
  position: relative;
  height: 100%;
  width: 60px;
  display: flex;
  flex-direction: column;
}
#main-return{
    height: 80px;
    /* background-color: rgb(45, 83, 83); */
    display: flex;
    justify-content: center;
    align-items: center;
}
#icon{

    width: 40px;
    height: 40px;
    /* background-color: rgb(223, 223, 223); */
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 10px;
    opacity: 0.3;
}
#icon:hover{
    background-color: rgb(205, 205, 205);
    opacity: 0.8;
}
#main-return  img{
    width: 50%;
    height: 50%;
}

#main-select{
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}

#main-select a{
    height: 50px;
    width: 45px;
    /* background-color: aqua; */
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    /* margin-top: 20px; */
    font-size: 12px;
    color: black;
    text-decoration: none;

    position: relative;
}
#main-select >div{
    display: flex;
    flex-direction: column;
    margin-top: 20px;
    border-radius: 5px;
    opacity: 0.65;
}

#main-select >div:hover{
    background-color: rgb(205, 205, 205);
    opacity: 0.8;
}

a img{
    width: 50%;
    height: 50%;
}

a span{
    margin-top: 5px;
}

#main-select2{
    position: absolute;
    bottom: 0px;
    /* background-color: aqua; */
    display: flex;
    flex-direction:column-reverse;
    /* justify-content: center; */
    align-items: center;
    height: 140px;
    width: 100%;
}

#main-select2 a{
    width: 45px;
    height: 45px;
    /* background-color: rgb(214, 214, 214); */
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 5px;
    opacity: 0.65;
}
#main-select2 a:hover{
    background-color: rgb(205, 205, 205);
    opacity: 0.8;
}
#main-select2 >div{
    /* background-color: rgb(57, 49, 38); */
    height: 60px;
    width: 60px;
    display: flex;
    justify-content: center;
    align-items: center;
}

#headimg{
    opacity: 0.8;
}
#headimg:hover{
    opacity: 1;
}
</style>
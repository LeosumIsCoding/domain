<template>
    <aside id="main-right">
        <div id="friend-list">
            <div id="friend-search">
                <input type="text" placeholder="搜索好友">
                <div id="friend-button">
                    <img src="../../assets/MainWindow/searchUser.png" alt="">
                </div>
            </div>

            <div id="friend-session">
                <Session v-for="s in friendList" :key="s.id"
                linkTo='/MainWindow/Friends/SessionWidget'
                
                :id="s.id"
                />
            </div>
        </div>

        <div id="friend-dialog">
            <keep-alive>
                <router-view></router-view>
            </keep-alive>
        </div>
    </aside>
</template>

<script>
import Header from "../MainWindow/Header.vue"
import {ipcRenderer} from "electron"
import Ipc from "./Ipc.vue"
import Session from "./Session.vue"

// import MyButton from "./MyButton.vue"
export default {
    name:"Friends",

    data() {
        return {
            friendList:[
            ]
        }
    },

    components:{
        Header,Ipc,Session
    },
    methods: {

    },

    mounted(){
        this.$http.get("http://localhost:4536/friend/getAllUserId")
        .then(res=>{
            // console.log(res.data);
            let arr = new Array();
            arr = res.data;
            console.log(arr, "arr");
            let list = [];
            arr.forEach(function(e){
                list.push({
                    id:e,
                    username:'leosum' + e,
                })
            })

            // console.log(list);
            this.friendList = list
        }, err=>{
            console.log(err);
        })
    }
}
</script>

<style scoped>

#main-right{
  flex: 1;
  /* background-color: rgb(255, 255, 255); */
  display: flex;
  flex-direction: row;
  
  height: 100%;
}

#friend-list{
    width: 200px;
    height: 100%;
    /* background-color: aqua; */
}
#friend-dialog{
    flex: 1;
    height: 100%;
    width: 100%;
    /* background-color: antiquewhite; */
}


#friend-list{
    display: flex;

    flex-direction: column;
    
}

#friend-search{
    height: 50px;
    width: 100%;
    /* background-color: azure; */
    display: flex;
    /* justify-content: center; */
    align-items: center;
}

#friend-search input{
    height: 25px;
    width: 140px;
    margin-left: 10px;
    outline: none;
    border-radius: 5px;
    border: 0px;
    /* text-align: center; */
    padding: 0px 10px 0px 10px ;
    background-color: rgb(231, 231, 231);
}

#friend-button{
    height: 30px;
    width: 30px;
    border-radius: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    /* background-color: rgb(50, 72, 92); */
    opacity: 0.65;
    margin-left: 10px;
    margin-right: 10px;
}
#friend-button:hover{
    background-color: rgb(205, 205, 205);
    opacity: 1;
}
#friend-button:active{
    background-color: rgb(178, 178, 178);
    opacity: 1;
}
#friend-button > img{
    height: 20px;
    width: 20px;
}

#friend-button > img:hover{
    /* background-color: aliceblue */
    background-color: rgba(240, 248, 255, 0);
}

#friend-session{
    height: 100%;
    width: 100%;
    flex: 1;
    overflow-y: scroll;
    /* background-color: antiquewhite; */
}
#friend-session a{
    height: 50px;
    width: 100%;
    /* background-color: aqua; */
    display: flex;
    align-items: center;


}
#friend-session a > img{
    height: 40px;
    width: 40px;
    margin-left: 5px;

}
</style>
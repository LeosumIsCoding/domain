<template>
    <aside id="main-right">
      <div id="main-header">
            <div id="Logo">
                <img src="../../assets/MainWindow/logo.png" alt="">
            </div>

            <div id="slot">
                123
            </div>

            <div id="controls">

                <div><input type="search" name="" id=""></div>

                <hr>
                <div id="ipc">
                    <div @click="minMainWindow">
                        <img src="../../assets/MainWindow/min.png" alt="">
                    </div>
                    <div @click="maxMainWindow"><img src="../../assets/MainWindow/max.png" alt=""></div>
                    <div @click="closeMainWindow"><img src="../../assets/MainWindow/close.png" alt=""></div>
                </div>

                
            </div>
      </div>
      <div id="main-content"> 
        <h2>content</h2>
      </div>
    </aside>
</template>

<script>
import Header from "../MainWindow/Header.vue"
import {ipcRenderer} from "electron"
export default {
    name:"Home",
    components:{
        Header
    },
    methods: {
        minMainWindow(){
            ipcRenderer.send("minMainWindow");
        },
        maxMainWindow(){
            ipcRenderer.send("maxMainWindow");
        },
        closeMainWindow(){
            ipcRenderer.send("closeMainWindow");
        }
    },
}
</script>

<style scoped>
hr{
    height: 18px;
    /* border: 1px solid black; */
    width: 0px;
    margin-top: 6px;
    margin-left: 20px;
    opacity: 0.3;
}
#main-right{
  flex: 1;
  background-color: rgb(255, 255, 255);
  display: flex;
  flex-direction: column;
  
  height: 100%;
}

#main-header{
  width: 100%;
  height: 80px;
  background-color: rgb(255, 255, 255);
  /* border: 1px solid black; */

  display: flex;
  /* justify-content: space-between; */
  align-items: center;
}

#main-content{
  flex: 1;
  /* background-color: brown; */
}

#controls{
    position: absolute;
    right: 0px;
}

#Logo{
    width: 150px;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
}
#Logo >img{
    height: 70%;
}

#slot{
    border: 1px solid black;
    height: 100%;
    width: 250px;
}

#controls{
    display: flex;
    flex-direction: row;
}

#ipc{
    display: flex;
    margin-right: 30px;
}
#ipc > div{
    height: 30px;
    width: 30px;
    /* background-color: aqua; */
    margin-left: 10px;
    border-radius: 5px;
    display: flex;
    justify-content: center;
    align-items: center;
    opacity: 0.65;
}
#ipc > div:hover{
    background-color: rgb(205, 205, 205);
    opacity: 1;
}
#ipc img{

    height: 60%;

}
</style>
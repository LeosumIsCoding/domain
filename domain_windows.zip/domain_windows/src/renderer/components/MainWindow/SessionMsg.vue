<template>
  <div id="session-msg">
    
    <div  id="friend-headimg" class="headimg">
        <img v-if="!isMe" :src="src" alt="">
    </div>

    <div id="msg-content">

        <div  v-if="!isMe" id="friend-msg" class="msg">
            {{msg}}

            <div v-if="!isMe"  id="friend-deco">

            </div>
        </div>
        <div v-if="isMe" id="my-msg" class="msg">
            {{msg}}
            <div  v-if="isMe"  id="friend-deco2">

            </div>
        </div>
    </div>


    <div  id="my-headimg" class="headimg"> 
        <img v-if="isMe" :src="src" alt="">
    </div>
  </div>
</template>

<script>
export default {
    name:"SessionMsg",
    computed:{
        src:function(){
            console.log("http://localhost:4536/photo?photoName=" + this.HeadimgSrc);
            return "http://localhost:4536/photo?photoName=" + this.HeadimgSrc;
        }
    },

    props:{
    HeadimgSrc:{
        type:String,
        // required:true,
        default:"defaultHeadimg.png"
    },
    msg:{
        type:String,
        required:true,
    },
    isMe:{
        type:Boolean,
        required:true
    }
    
}
}
</script>

<style>
#session-msg{
    display: flex;
    justify-content: space-between;
}
/* #session-msg>div:nth-child(1){


} */
.headimg{
    height: 50px;
    width: 50px;
    /* background-color: aqua; */
    display: flex;
    justify-content: center;
    align-items: center;
}
.headimg>img{
    height: 40px;
    width: 40px;
    border-radius: 3px;

}
#session-msg>div:nth-child(2){
    /* height: 200px; */
    flex: 1;
    /* background-color: aquamarine; */
    padding: 10px;
}
#session-msg>div:nth-child(3){
    height: 50px;

}

#my-msg{
    float: right;
}

#friend-msg{
    float: left;
}

.msg{
    background-color: #6cf;
    padding: 10px;
    border-radius: 5px;
    color: rgb(255, 255, 255);
    position: relative;

    word-break: break-all;
}

#friend-deco{

    width: 0px;
    height: 0px;
    /* background-color: aquamarine; */
    position: absolute;
    left: -32px;
    top: 10px;
    border-top: 5px solid rgba(255, 255, 255, 0);
    border-left: 20px solid rgba(102, 203, 221, 0);
    border-bottom: 5px solid rgba(102, 204, 170, 0);
    border-right: 20px solid #6cf;

    transform: rotate(20deg);
}

#friend-deco2{
    width: 0px;
    height: 0px;
    /* background-color: aquamarine; */
    position: absolute;
    right: -39px;
    top: 10px;
    border-top: 5px solid rgba(255, 255, 255, 0);
    border-left: 20px solid #6cf;
    border-bottom: 5px solid rgba(102, 204, 170, 0);
    border-right: 25px solid rgba(102, 204, 255, 0);

    transform: rotate(-20deg);
}
</style>
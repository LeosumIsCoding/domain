<template>
  <div id="session-dialog">

    <SessionTitle ref="sessionTitle" :id='id'/>

    <div id="session-content" ref="content">
        <SessionMsg  v-for="(m, index) in msgList" :key="index"
            :HeadimgSrc="m.headimg" :msg="m.msg" :isMe="m.isMe"
        />

    </div>

    <div id="session-input">

        <div>
            <div class="input-func">
                <div v-show="EmojiShow" class="input-emoji">
                    <div id="emoji-deco">

                    </div>
                </div>

                <a @focus="showEmoji" @blur="hideEmoji" @ id="emojo-icon" href="#">

                    <img src="../../assets/MainWindow/Emoji-1.png" alt="">
                </a>
                <a href="#">
                    <img src="../../assets/MainWindow/file.png" alt="">
                </a>
                
            </div>

            <div class="input-func">
                <a href="#">
                    <img src="../../assets/MainWindow/Emoji-1.png" alt="">
                </a>
            </div>
        </div>
<!--  -->
        <div id="input-input">
            <textarea v-model="msg" name="" id="" cols="30" rows="10"></textarea>

            <button @click="sendMsg">发送</button>
        </div>
    </div>
  </div>
</template>

<script>

import SessionTitle from "./SessionTitle.vue"
import SessionMsg from "./SessionMsg.vue"
export default {
    name:"SessionWidget",
    components:{SessionTitle, SessionMsg},
    data() {
        return {
            friendData:null,
            id:"123",
            msgList:[],
            msg:'msg',
            EmojiShow:false
        }
    },
    beforeMount() {
        // console.log( this.$route,"id111111111111111111111111");

    },

    beforeRouteUpdate(to, from, next) {
        console.log(this.$route,"被复用");
       
        next();

        let data = JSON.parse(this.$route.params.data);

        // console.log(this.$route);
        this.id = this.$route.params.data;

        this.$refs.sessionTitle.updateData(data.username);

        this.msgList = data.msgList;

        
        
    },
    methods: {
        sendMsg(){
            let msg = {
                isMe:true,
                msg:this.msg,
                headimg:this.headimg,
            }
            this.msgList.push(msg);
            this.$nextTick(()=>{
                let scrollHeight = this.$refs.content.scrollHeight +200;
                this.$refs.content.scrollTop = scrollHeight
            })
        },
        showEmoji(){
            this.EmojiShow = true;
        },
        hideEmoji(){
            this.EmojiShow = false;
        }
    },

}

</script>

<style scoped>
#session-dialog{
    height: 100%;
    width: 100%;
    /* background-color: aqua; */
    display: flex;
    flex-direction: column;
}

#session-title{
    height: 50px;
    width: 100%;
    /* background-color: antiquewhite; */
}

#session-input{
    height: 150px;
    width: 100%;
    /* background-color: aqua; */
    display: flex;
    flex-direction: column;
}
#session-input>div{
    height: 30px;
    width: 100%;
    display: flex;
    /* background-color: aqua; */
    align-items: center;
    justify-content: space-between;
    /* margin-top: 5px; */
    /* background-color: antiquewhite; */
}
#session-input>div:nth-child(1){
    margin-top: 5px;
}
.input-func{
    height: 30px;
    /* width: 80px; */
    /* background-color: antiquewhite; */
    display: flex;
    justify-content: center;
    align-items: center;
    /* opacity: 0.65; */
    margin-left: 20px;
    margin-right: 20px;
    position: relative;
}

.input-func > a > img{
    height: 20px;
    width: 20px;
    margin: 5px;
}
.input-func > a{
    opacity: 0.65;
    width: 30px;
    height: 30px;
    border-radius: 5px;
    /* margin: 0px 5px 0px 10px; */
    /* position: relative; */
}
.input-func > a:hover{
    opacity: 1;
    background-color: rgb(205, 205, 205);
}

.input-func > a:active{
    opacity: 1;
    background-color: rgb(182, 182, 182);
}

#input-input{
    /* background-color: aqua; */
    /* height: 100%; */
    flex: 1;
    display: flex;
    flex-direction: column;

}
#input-input>textarea{
    height: 80%;
    width: 100%;
    padding: 5px 20px 0px 20px;
    border: none;
    outline: none;
    font-weight: 900;
}
#input-input > button{
    position: absolute;
    right: 30px;
    bottom: 10px;
    width: 100px;
    height: 30px;
    outline: none;
    border: none;
    opacity: 0.65;
    background-color: rgb(225, 225, 225);
    font-weight: 800;
    border-radius: 5px;
}
#input-input > button:hover{
    background-color: rgb(205,  205, 205);
}
#input-input > button:active{
    background-color: rgb(184, 184, 184);
}
#session-content{
    width: 100%;
    flex: 1;
    /* background-color: beige; */
    overflow-y: scroll;
}
#session-content::-webkit-scrollbar{
    width: 5px;
    background-color: rgb(255, 255, 255);
}
#session-content::-webkit-scrollbar-thumb{
    background-color: rgb(206, 206, 206);
    border-radius: 3px;
}

.input-emoji{
    position: absolute;
    height: 200px;
    width: 300px;
    background-color: rgb(255, 255, 255);
    bottom: 40px;
    left: 0px;
    box-shadow: -1px 1px 20px rgba(0, 0, 0, 0.356) ;

    border-radius: 15px;
    /* display: none; */
}


#emoji-deco{
    position: absolute;
    /* background-color: antiquewhite; */
    bottom: -10px;
    left: 15px;
    width: 0px;
    height: 0px;
    border-top: 20px solid rgba(114, 6, 6, 0);
    border-left: 20px solid rgb(255, 255, 255);
    border-bottom: 20px solid rgba(0, 0, 0, 0);
    border-right: 20px solid rgba(255, 228, 196, 0);
}


</style>
<template>
  <div>
    <button id="my-button"  :style="{
        color,
        backgroundColor,
        width,
        height,
        margin,
        fontSize,
        borderRadius
    }">
        <img v-if="iconSrc != null" :src="iconSrc" alt="">
        {{buttomName}}
    </button>
  </div>
</template>

<script>
export default {
    name:'MyButton',

    props:{
        buttomName:{
            type:String,
            default:'按钮'
        },
        color:{
            type:String,
            default:'#000'
        },
        backgroundColor:{
            type:String,
            default:'#fff'
        },
        width:{
            type:String,
            default:'100px'
        },
        height:{
            type:String,
            default:'30px'
        },
        margin:{
            type:String,
            default:'10px 10px 10px 10px',
        },
        iconSrc:{
            type:String,
            default:null
        },

        fontSize:{
            type:String,
            default:"9px"
        },
        borderRadius:{
            type:String,
            default:"0px"
        }

    },

    methods:{

    }

}
</script>

<style scoped>
#my-button{
        border: none;
    border-radius: 20px;
    outline:none;
    display: flex;
    justify-content: center;
    align-items: center;
    opacity: 0.65;
}


#my-button:hover{
        opacity: 1;
        /* width: 40px; */
        background-color: rgb(255, 255, 255);
        
}
#my-button:active{
        opacity:1;
         /* transform: translate(10px, 20px) rotate(45deg); */
        border: none;
}
#my-button img{
    height: 10px;
    width: 20px;
}
</style>
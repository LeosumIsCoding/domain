<template>
    <div id="session-title">
        <div id="title-name">
            {{username}}
        </div>
        <!-- <hr> -->
        <div id="titile-ipc">
            
            <Ipc/>
        </div>
    </div>
</template>

<script>
import Ipc from './Ipc.vue'
export default {
    name:"SessionTitle",
    components:{Ipc},
    data() {
        return {
            username:"null"
        }
    },
    props:{
        id:{
            type:String,
            require:true,
        }
    },

    methods:{
        updateData(username){
            this.username = username
            // console.log(id,"id, session");
            // this.$http.get(`http://localhost:4536/friend/username/${id}`)
            // .then(res=>{
            //     console.log(res.data,"data");
            //     this.username = res.data;
            //     // console.log(this.username);
            // }, err=>{
            //     console.log(err);
            // })
        }
    },

}
</script>

<style scoped>
#session-title{
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
}

#title-name{
    margin-left: 20px;
    font-size: 20px;
    font-weight: 800;
}
</style>
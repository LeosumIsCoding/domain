<template>
  <div ref="mainWindow" id="main">


    <MainLeft/>

    <keep-alive>
      <router-view></router-view>
    </keep-alive>
     




  </div>
</template>

<script>

import {ipcRenderer} from "electron"

import MainWindowStore from "../store/MainWindowStore.js"

import MainLeft from "./MainWindow/MainLeft.vue"
import MainRight from "./MainWindow/MainRight.vue"
export default {
    name:"MainWindow",
    components:{
      MainLeft,MainRight
    },
    mounted() {
      ipcRenderer.once("MainWindoReady",(event,res)=>{
        console.log(res);
        this.$store.state.myInfo = res.data;
      })

      ipcRenderer.on('mainWinSizeChanged',(event,size)=>{
            this.$refs.mainWindow.style.height = size.height +'px';
            console.log(size);
      });

      
    },

    store:MainWindowStore
}
</script>

<style>
#main{
  display: flex;
  height: 507px;
  width: 100%;

}


</style>
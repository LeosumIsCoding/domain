import fs from 'fs'

export default{
    methods: {
        tran2Base64(fileUrl){
            var reg=/\\/ig;
            fileUrl = fileUrl.replace(reg, '/');
        
            let dataStr;
            fs.readFile(fileUrl,(err, data)=>{
                if(err){
                console.log(err,"error");
                dataStr = 0;
                // return 0;
                }else{
                // console.log(data,"pictran");
                
                // console.log(data.toString('base64'))
                dataStr = data;
            //    return 1;
                
                // console.log("success!");
                }
            
            })
            console.log(dataStr,"hahahahahahahhah");
            
        }
    },
}
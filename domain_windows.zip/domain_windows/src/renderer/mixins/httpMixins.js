import axios from 'axios'

console.log("融入http", axios);
export default{
    methods: {
        tranUrl(fileUrl){
            var reg=/\\/ig;
            fileUrl = fileUrl.replace(reg, '/');
            return fileUrl;
        }
    },
}
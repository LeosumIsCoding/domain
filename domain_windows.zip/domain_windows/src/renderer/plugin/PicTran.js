export default {
    install(Vue, options){
        // console.log(Vue);
        console.log("12323131312")
        Vue.prototype.$Tran2Base64 = function(fileUrl){
            var reg=/\\/ig;
            fileUrl = fileUrl.replace(reg, '/');
            
            fs.readFile(fileUrl,(err, data)=>{
                if(err){
                console.log(err,"error");
                return;
                }else{
                console.log(data,options,"pictran");
                
                // console.log("success!");
            }
        })
        }


        
    }
}

import fs from 'fs';
// 该文件用于创建vuex中最核心的store

// 引入Vue
import Vue from 'vue'
// 引入Vuex
import Vuex from 'vuex'


// console.log(Vue,"hahahahahahahha");
// 准备actions--用于响应组件中的动作
const action = {


};

//准备mutations -- 用与操作数据（state）
const mutations = {


    
};



// 准备state--用于存储数据
const state = {
    myInfo:{
        id:53,
        username:root,
        password:123456,
        headimg:"defaultHeadimg.png",
    }
};


const getters = {


}

Vue.use(Vuex)
export default new Vuex.Store({
    actions:action,
    mutations:mutations,
    state:state,
    getters
})
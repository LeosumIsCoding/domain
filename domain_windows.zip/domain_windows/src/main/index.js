import { app, BrowserWindow, ipcMain } from 'electron'
import '../renderer/store'

/**
 * Set `__static` path to static files in production
 * https://simulatedgreg.gitbooks.io/electron-vue/content/en/using-static-assets.html
 */
if (process.env.NODE_ENV !== 'development') {
  global.__static = require('path').join(__dirname, '/static').replace(/\\/g, '\\\\')
}

let mainWindow
const winURL = process.env.NODE_ENV === 'development'
  ? `http://localhost:9080`
  : `file://${__dirname}/index.html`

function createWindow (data) {
  /**
   * Initial window options
   */
  mainWindow = new BrowserWindow({
    height: 563,
    // useContentSize: true,
    width: 1000,
    minHeight:500
  })

  mainWindow.loadURL(winURL+"#/MainWindow/Friends")

  mainWindow.on('closed', () => {
    mainWindow = null
  })

  // mainWindow.on("ready-to-show", ()=>{
  //   mainWindow.webContents.send("MainWindoReady", data);
  //   console.log(data,"sdsadasdasdadsa");
  // } )
  console.log(data, "create");
  setTimeout(function(){
    mainWindow.webContents.send("MainWindoReady", data);
    console.log(data,"sdsadasdasdadsa",mainWindow);
  },400)

 

  mainWindow.on("resize",(e)=>{
    let size = mainWindow.getContentBounds();
    mainWindow.webContents.send("mainWinSizeChanged",size); //    事件     登陆窗体大小改变
  })
}
// 主窗体事件

ipcMain.on("minMainWindow",()=>{
  mainWindow.minimize()
})

ipcMain.on("maxMainWindow",()=>{
  if(mainWindow.isMaximized()){
    mainWindow.restore()
  }else{
     mainWindow.maximize()
  }
})
ipcMain.on("closeMainWindow",()=>{
  mainWindow.close()
})

//



console.log("Main Listening......");

// 创建 登陆窗体函数
let loginWindow

function createLoginWindow(){
  loginWindow = new BrowserWindow({
    height:450,
    width:600,
    // useContentSize:true,
    maxHeight:450,
    maxWidth:600,

    minHeight:450,
    minWidth:300,

    frame:false,
    transparent: true,
    webPreferences:{
      devTools:false,
      nodeIntegration:true,
      enablemotemodule:true
    }
  })

  loginWindow.loadURL(winURL+"#/LoginWindow")

  loginWindow.on('close', ()=>{
    loginWindow = null
  })
  
  loginWindow.on("resize",(e)=>{
    let size = loginWindow.getContentBounds();
    loginWindow.webContents.send("loginWinSizeChanged",size); //    事件     登陆窗体大小改变
  })
  // loginWindow.minimize()
}

//                                             登录窗体最小化事件
ipcMain.on("minLoginWindow",()=>{
  console.log(loginWindow);
  loginWindow.minimize()
})
//                                              关闭登录窗体
ipcMain.on("closeLoginWindow", ()=>{
  loginWindow.close()
})
//                                              登录主窗体

ipcMain.on("go2MainWindow", (event, data)=>{
  console.log(event,data, "ipcmain");
  loginWindow.close();
  createWindow(data)
})




app.on('ready', createLoginWindow)

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})

app.on('activate', () => {
  if (mainWindow === null) {
    createWindow()
  }
})



/**
 * Auto Updater
 *
 * Uncomment the following code below and install `electron-updater` to
 * support auto updating. Code Signing with a valid certificate is required.
 * https://simulatedgreg.gitbooks.io/electron-vue/content/en/using-electron-builder.html#auto-updating
 */

/*
import { autoUpdater } from 'electron-updater'

autoUpdater.on('update-downloaded', () => {
  autoUpdater.quitAndInstall()
})

app.on('ready', () => {
  if (process.env.NODE_ENV === 'production') autoUpdater.checkForUpdates()
})
 */

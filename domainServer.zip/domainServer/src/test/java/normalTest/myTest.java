package normalTest;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.logging.SimpleFormatter;

public class myTest {

    public static void main(String[] args) {

        SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
        String nowtime = df.format(new Date());

        System.out.println(nowtime);
    }
}

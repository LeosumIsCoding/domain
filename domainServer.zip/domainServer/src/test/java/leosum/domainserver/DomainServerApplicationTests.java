package leosum.domainserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Date;

@SpringBootTest
class DomainServerApplicationTests {

    @Test
    void contextLoads() {
        Date date = new Date();

        System.out.println(date.getTime());
    }

}

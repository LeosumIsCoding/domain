package leosum.domainserver.Services;

import leosum.domainserver.Enities.User;
import leosum.domainserver.Mappers.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class UserService {

    @Autowired
    private UserMapper userMapper;


    public int insertUserInfo(User user){
        return userMapper.InsertUser(user);
    }

    public int isUserExist(String username){
        User user = userMapper.getUserInfoByUsername(username);
        System.out.println(user);
        if(user == null){
            return 0;
        }
        return 1;
    }

    public User getUserInfo(String username){
        User user = userMapper.getUserInfoByUsername(username);
        return user;
    }

    public List<Integer> getAllUserId(){
        List<Integer> idList = userMapper.getAllUserId();
        return idList;
    }


    public User getUserInfoById(Integer id){
        User user = userMapper.getUserInfoById(id);
        return user;
    }


    public String getUserNameById(Integer id){
        String name = userMapper.getUserNameById(id);
        return name;
    }
}

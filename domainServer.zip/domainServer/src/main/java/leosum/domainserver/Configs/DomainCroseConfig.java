package leosum.domainserver.Configs;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class DomainCroseConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry){
        registry.addMapping("/**")
                .allowCredentials(true)//是否发送Cookie
                .allowedOriginPatterns("http://localhost:9080") // 放行哪些原始域
                .allowedMethods(new String[]{"GET", "POST", "PUT", "DELETE"}) // 放行哪些请求方式
                .allowedHeaders("*") // 放行哪些原始请求头部信息
                .exposedHeaders("*");// 暴露那些原始请求头部信息
    }
}

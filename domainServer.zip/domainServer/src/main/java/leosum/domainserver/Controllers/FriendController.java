package leosum.domainserver.Controllers;


import leosum.domainserver.Enities.User;
import leosum.domainserver.Services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequestMapping("/friend")
public class FriendController {

    @Autowired
    private UserService userService;

    @GetMapping("/getAllUserId")
    @ResponseBody
    public List<Integer> getAllUserId(){
        List<Integer> idList = userService.getAllUserId();
        return idList;
    }


    @GetMapping("/{id}")
    @ResponseBody
    public User getUserById(@PathVariable("id") Integer id){
        User user = userService.getUserInfoById(id);
        return user;
    }

    @GetMapping("/username/{id}")
    @ResponseBody
    public String getUserNameById(@PathVariable("id") Integer id){
        String name = userService.getUserNameById(id);
        return name;
    }


}

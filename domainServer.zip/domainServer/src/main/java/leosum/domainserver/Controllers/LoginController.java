package leosum.domainserver.Controllers;

import leosum.domainserver.Enities.User;
import leosum.domainserver.Services.UserService;
//import leosum.domainserver.Services.UserServiceImpl;
import leosum.domainserver.Utils.Base64TranUtils;
import leosum.domainserver.Utils.DateTranUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;

@RequestMapping("/User")
//@CrossOrigin(origins = "*", maxAge = 360)
@Controller
public class LoginController {
    @Autowired
    private UserService userService;

    @Value("${domain.photoUrl}")
    private String photoUrl;


    @ResponseBody
    @PostMapping("/userInfo")
    public Integer userRegister(HttpServletResponse resp, @RequestBody User user, HttpServletRequest req) throws FileNotFoundException {
        int statu = 0;
        String headimgBase64 = user.getHeadimg();

        String src = null;

        if ( "default".equals(user.getHeadimg())){
            user.setHeadimg("defaultHeadimg.png");
            try{
                statu = userService.insertUserInfo(user);
            }catch (Exception e){
                System.out.println(e);
                return -1;
            }
            return statu;
        }else{
//            String headimgSrc = Base64TranUtils.Base64Tran2PNG(user.getHeadimg(),user.getUsername());
            String nowTime = DateTranUtils.getNowTime();
            user.setHeadimg(user.getUsername() + nowTime + ".png");
            try{
                statu = userService.insertUserInfo(user);
            }catch (Exception e){

                System.out.println(e);
                System.out.println("--------------------------------------");
                return -1;
            }
            Base64TranUtils.Base64Tran2PNG(headimgBase64,user.getUsername(), photoUrl);
            return  statu;
        }

    }



    @GetMapping("/userInfo")
    @ResponseBody
    public User getUserInfo(String username){
        User user = userService.getUserInfo(username);

        return user;
    }


    @GetMapping(value = "/userExist", produces = "application/json;charset=UTF-8")
    @ResponseBody
    public Integer isUserExist(HttpServletResponse resp, String username){

        int statu = userService.isUserExist(username);
        System.out.println(statu);
//        PrintWriter out = null;
//        try{
//            resp.setContentType("application/json;charset=UTF-8");
//            out = resp.getWriter();
//
//            out.write("username:123");
//
//            out.flush();
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        }finally {
//            if(out != null){
//                out.close();
//            }
//        }
//        out.close();
//        return user;

        return statu;
    }



}

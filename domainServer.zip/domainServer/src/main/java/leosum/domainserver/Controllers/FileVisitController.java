package leosum.domainserver.Controllers;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;


@Controller
public class FileVisitController {

    @Value("${domain.FileBaseUrl}")
    private String FileBaseUrl;
    @Value("${domain.photoUrl}")
    private String photoUrl;

    @GetMapping("/photo")
//    @ResponseBody
    public void getPhoto(String photoName, HttpServletResponse resp) throws IOException {

        File file = new File(photoUrl+photoName);

        resp.setContentType("image/jpeg");
        try{
            FileInputStream fileInputStream = new FileInputStream(file);
            ServletOutputStream outputStream = resp.getOutputStream();
            byte[] bytes = new byte[1024];
            int len = 0;
            while((len = fileInputStream.read(bytes)) != -1){
                outputStream.write(bytes,0, len);
                outputStream.flush();
            }
            outputStream.close();
            fileInputStream.close();
        }catch (Exception e){
            System.out.println(e);
        }
    }
}

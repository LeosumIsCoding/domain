package leosum.domainserver.Utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class DateTranUtils {

    public static String getNowTime(){

        SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
        String nowtime = df.format(new Date());
        return nowtime;
    }


}

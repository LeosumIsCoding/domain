package leosum.domainserver.Utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Base64;
import java.util.Date;

public class Base64TranUtils {




    //                                  传入base64字符串    根据id给要生成的图片命名
    public static String Base64Tran2PNG(String base64String, String username, String url){
        String nowTime = DateTranUtils.getNowTime();
        try{
            byte[] base64Bytes = Base64.getDecoder().decode(base64String);

            for(int i = 0; i< base64Bytes.length; i++){
                if(base64Bytes[i] <0){
                    base64Bytes[i] += 256;
                }
            }

            String photoPath = url + username + nowTime + ".png";
            File tempFile = new File(photoPath);
            if(!tempFile.getParentFile().exists()){
                tempFile.getParentFile().mkdirs();
            }

            OutputStream out = new FileOutputStream(tempFile);
            out.write(base64Bytes);
            out.flush();
            out.close();
        }catch(Exception e){
            System.out.println(e);
        }
        String src = url + username + nowTime + ".png";
        return src;
    }
}

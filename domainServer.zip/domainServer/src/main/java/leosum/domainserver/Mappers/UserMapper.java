package leosum.domainserver.Mappers;


import leosum.domainserver.Enities.User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface UserMapper {

    @Insert("Insert into users (username, password, statu, headimg) values (#{username}, #{password}, #{statu}, #{headimg})")
    public int InsertUser(User user);

    @Select("select id, username, password, statu, headimg from users where username=#{username}")
    public User getUserInfoByUsername(String username);

    @Select("select id from users")
    public List<Integer> getAllUserId();

    @Select("select id, username, statu, headimg from users where id=#{id}")
    public User getUserInfoById(Integer id);

    @Select("select username from users where id=#{id}")
    public String getUserNameById(Integer id);

}
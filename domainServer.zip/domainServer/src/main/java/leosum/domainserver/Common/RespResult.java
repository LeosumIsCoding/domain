package leosum.domainserver.Common;

public class RespResult {

    public String json;


}
